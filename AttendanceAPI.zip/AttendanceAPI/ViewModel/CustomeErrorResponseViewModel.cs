﻿namespace AttendanceAPI.ViewModel
{
    public class CustomeErrorResponseViewModel
    {
        public int Status { get; set; }
        public string Error { get; set; }
        public string Data { get; set; }
    }
}
